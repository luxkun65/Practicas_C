#ifndef PARALELOGRAMO_H
#define PARALELOGRAMO_H

#include"Rectangulo.h"

class Paralelogramo: public Rectangulo
{
    public:
        Paralelogramo();
        virtual ~Paralelogramo();

    protected:

    private:
};

#endif // PARALELOGRAMO_H
