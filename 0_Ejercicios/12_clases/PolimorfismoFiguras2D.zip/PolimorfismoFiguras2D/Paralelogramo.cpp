#include "Paralelogramo.h"

Paralelogramo::Paralelogramo()
{
    //ctor
}

Paralelogramo::~Paralelogramo()
{
    //dtor
}
